package com.example.snowtimerapp.ui.screens.home

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.snowtimerapp.ui.screens.search.Course
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class StudyItem(
    val title: String,
    val isRunning: Boolean = false,
    val seconds: Int = 0,
    val lastStartTime: Long = 0L,            // ✅ 팀원 코드에서 가져온 필드
    val todos: MutableList<Todo> = mutableListOf()
)

data class Todo(
    val text: String,
    val checked: Boolean = false
)

class TimerViewModel : ViewModel() {

    // 🔹 Firestore
    private val db = FirebaseFirestore.getInstance()
    private var currentUid: String? = null

    // 🔹 로컬 상태 (Compose에서 쓰는 상태)
    var studyItems by mutableStateOf(defaultStudyItems())
        private set

    // 🔹 총 공부 시간 (기존 방식 유지)
    val totalSeconds: Int
        get() = studyItems.sumOf { it.seconds }

    // 🔹 팀원 코드에서 가져온: 과목별 타이머 Job 관리
    private val timerJobs = mutableMapOf<String, Job>()

    init {
        // ✅ 예전에는 여기서 startTimerUpdates()를 돌렸는데,
        //    이제는 과목별로 startTimer() 호출할 때만 Job을 돌리므로 필요 없음.
        // setUser()는 HomeTimerScreen 쪽 LaunchedEffect에서 호출해 주고 있음.
    }

    // -------------------------
    // 1. 유저 설정 + Firestore에서 과목 로딩
    // -------------------------
    fun setUser(navUid: String? = null) {
        // 1️⃣ 항상 Auth에서 uid를 다시 확인
        val authUid = FirebaseAuth.getInstance().currentUser?.uid

        // 로그인 안 된 상태면 그냥 리턴
        if (authUid == null) {
            return
        }

        // 2️⃣ currentUid 를 "Auth 기준 uid"로만 저장
        if (currentUid == authUid) return

        currentUid = authUid
        loadStudyItemsFromFirestore()
    }

    private fun loadStudyItemsFromFirestore() {
        val uid = currentUid ?: return
        val userDoc = db.collection("users").document(uid)

        // 1차: subjects 컬렉션에서 과목 기본 정보 로딩
        userDoc.collection("subjects")
            .get()
            .addOnSuccessListener { snapshot ->
                // 우선 todos 비어있는 StudyItem 리스트 생성
                val baseItems = snapshot.documents.map { doc ->
                    val title = doc.getString("title") ?: doc.id
                    val isRunning = doc.getBoolean("isRunning") ?: false
                    val seconds = (doc.getLong("seconds") ?: 0L).toInt()
                    val lastStartTime = doc.getLong("lastStartTime") ?: 0L

                    StudyItem(
                        title = title,
                        isRunning = isRunning,
                        seconds = seconds,
                        lastStartTime = lastStartTime,
                        todos = mutableListOf()
                    )
                }

                // 비어있으면 기본 목록, 아니면 subjects 기반 세팅
                studyItems = if (baseItems.isNotEmpty()) baseItems else defaultStudyItems()

                // 2차: 각 subject의 todos 서브컬렉션 로딩
                snapshot.documents.forEach { subjectDoc ->
                    val subjectTitle = subjectDoc.getString("title") ?: subjectDoc.id

                    subjectDoc.reference
                        .collection("todos")
                        .get()
                        .addOnSuccessListener { todosSnap ->
                            val todos = todosSnap.documents.map { todoDoc ->
                                Todo(
                                    text = todoDoc.getString("text") ?: "",
                                    checked = todoDoc.getBoolean("checked") ?: false
                                )
                            }.toMutableList()

                            // 해당 제목의 StudyItem에 todos 주입
                            studyItems = studyItems.map { item ->
                                if (item.title == subjectTitle) {
                                    item.copy(todos = todos)
                                } else item
                            }
                        }
                }
            }
            .addOnFailureListener {
                // 실패 시에는 그냥 기존 studyItems 유지 (필요하면 로그 추가)
            }
    }

    // -------------------------
    // 2. Firestore에 현재 과목 + todos 저장
    //    - subjects 문서: title, isRunning, seconds, lastStartTime
    //    - subjects/{title}/todos 서브컬렉션: text, checked
    // -------------------------
    private fun saveStudyItemsToFirestore() {
        val uid = currentUid ?: return
        val userDoc = db.collection("users").document(uid)

        studyItems.forEach { item ->
            val subjectRef = userDoc.collection("subjects").document(item.title)

            // 1) 과목 기본 정보 업데이트
            val subjectData = mapOf(
                "title"         to item.title,
                "isRunning"     to item.isRunning,
                "seconds"       to item.seconds,
                "lastStartTime" to item.lastStartTime
            )
            subjectRef.set(subjectData, SetOptions.merge())

            // 2) todos 서브컬렉션 동기화
            val todosRef = subjectRef.collection("todos")

            // 기존 todos 싹 지우고, 현재 state 기준으로 다시 채우기
            todosRef.get().addOnSuccessListener { snap ->
                val batch = db.batch()

                // 기존 todos 삭제
                snap.documents.forEach { doc ->
                    batch.delete(doc.reference)
                }

                // 현재 StudyItem.todos로 다시 채우기
                item.todos.forEach { todo ->
                    val todoDoc = todosRef.document() // auto-id
                    val todoData = mapOf(
                        "text"    to todo.text,
                        "checked" to todo.checked
                    )
                    batch.set(todoDoc, todoData)
                }

                batch.commit()
            }
        }
    }

    // -------------------------
    // 3. 기본 과목 리스트 (처음엔 비워둠)
    // -------------------------
    private fun defaultStudyItems(): List<StudyItem> =
        listOf()

    // -------------------------
    // 4. 팀원 버전 타이머 로직: 과목별 Job 기반
    // -------------------------

    /** 한 과목 타이머 시작 (기존 toggleTimer에서 사용) */
    fun startTimer(title: String) {
        // 한 번에 하나만 돌도록 기존 것 전부 정지
        stopAllTimers()

        // 이미 Job 있으면 무시
        if (timerJobs.containsKey(title)) return

        val now = System.currentTimeMillis()

        // 선택된 과목만 isRunning = true, 나머지는 false
        studyItems = studyItems.map { item ->
            if (item.title == title) {
                item.copy(isRunning = true, lastStartTime = now)
            } else {
                item.copy(isRunning = false)
            }
        }

        // 실제 타이머 Job 시작
        val job = viewModelScope.launch {
            while (true) {
                delay(1000L)
                studyItems = studyItems.map { item ->
                    if (item.title == title && item.isRunning) {
                        item.copy(seconds = item.seconds + 1)
                    } else {
                        item
                    }
                }
                // 매초 Firestore 저장은 트래픽 부담 크므로 여기서는 저장 X
            }
        }

        timerJobs[title] = job
    }

    /** 한 과목 타이머 정지 */
    fun stopTimer(title: String) {
        timerJobs[title]?.cancel()
        timerJobs.remove(title)

        studyItems = studyItems.map { item ->
            if (item.title == title) {
                item.copy(isRunning = false)
            } else item
        }
        saveStudyItemsToFirestore()
    }

    /** 모든 과목 타이머 정지 */
    private fun stopAllTimers() {
        timerJobs.values.forEach { it.cancel() }
        timerJobs.clear()

        studyItems = studyItems.map { item ->
            if (item.isRunning) item.copy(isRunning = false) else item
        }
    }

    // -------------------------
    // 5. 타이머 토글 (기존 외부 API 유지)
    // -------------------------
    fun toggleTimer(itemTitle: String) {
        val target = studyItems.find { it.title == itemTitle }

        if (target == null) return

        if (target.isRunning) {
            // 이미 돌고 있으면 정지
            stopTimer(itemTitle)
        } else {
            // 안 돌고 있으면 시작
            startTimer(itemTitle)
        }

        // 타이머 상태 바뀔 때만 Firestore 저장
        saveStudyItemsToFirestore()
    }

    // -------------------------
    // 6. To-do 리스트 갱신 (HomeTodoScreen에서 호출)
    // -------------------------
    fun updateStudyItems(updated: List<StudyItem>) {
        studyItems = updated
        saveStudyItemsToFirestore()
    }

    // -------------------------
    // 7. 검색 화면에서 과목 추가 (기존 로직 유지)
    // -------------------------
    fun addCourseAsStudyItem(course: Course) {
        // 항상 Auth 기준 uid 사용
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        currentUid = uid

        // 이미 같은 제목 과목 있으면 무시 (중복 방지)
        if (studyItems.any { it.title == course.name }) return

        val newItem = StudyItem(
            title = course.name
        )

        // 로컬 업데이트
        studyItems = studyItems + newItem

        // Firestore에 즉시 반영
        val userDoc = db.collection("users").document(uid)
        val subjectRef = userDoc.collection("subjects").document(newItem.title)

        val subjectData = mapOf(
            "title"     to newItem.title,
            "isRunning" to newItem.isRunning,
            "seconds"   to newItem.seconds,
            "lastStartTime" to newItem.lastStartTime
        )

        subjectRef.set(subjectData, SetOptions.merge())
        // todos는 비어있으니 여기선 따로 쓸 게 없음 (나중에 To-do 추가하면 saveStudyItemsToFirestore 통해 반영)
    }

    override fun onCleared() {
        super.onCleared()
        // ✅ ViewModel 죽을 때 모든 Job 정리
        stopAllTimers()
    }

    fun deleteSubject(title: String) {
        // 🔹 항상 Auth 기준 uid 사용
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        currentUid = uid

        // 1) 로컬 상태에서 먼저 제거
        studyItems = studyItems.filterNot { it.title == title }

        // 2) Firestore에서도 삭제
        val userDoc = db.collection("users").document(uid)
        val subjectRef = userDoc.collection("subjects").document(title)

        // todos 서브컬렉션 먼저 삭제 후 과목 문서 삭제
        subjectRef.collection("todos")
            .get()
            .addOnSuccessListener { snap ->
                val batch = db.batch()

                // todos 전부 삭제
                snap.documents.forEach { doc ->
                    batch.delete(doc.reference)
                }

                // subject 문서 삭제
                batch.delete(subjectRef)

                batch.commit()
            }
    }
}