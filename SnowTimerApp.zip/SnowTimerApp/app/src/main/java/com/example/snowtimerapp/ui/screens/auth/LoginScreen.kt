package com.example.snowtimerapp.ui.screens.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.snowtimerapp.R
import com.example.snowtimerapp.ui.theme.SnowTimerAppTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

// 앱 제목용 폰트 (이미 다른 파일에 있으면 이 선언은 지워도 됨)
val wooju = FontFamily(Font(R.font.wooju))

@Composable
fun LoginScreen(navController: NavController) {
    var id by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val auth = FirebaseAuth.getInstance()
    val store = FirebaseFirestore.getInstance()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // 로고 + 앱 이름
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 30.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo_1),
                contentDescription = "Logo Image",
                modifier = Modifier.size(35.dp)
            )
            Spacer(Modifier.width(7.dp))
            Text(
                text = "눈송이를 품은 타이머",
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.Black,
                fontFamily = wooju
            )
        }

        // 아이디 입력
        OutlinedTextField(
            value = id,
            onValueChange = { id = it },
            placeholder = { Text("아이디를 입력하세요", color = Color.LightGray) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .height(52.dp),
            shape = RoundedCornerShape(12.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                disabledContainerColor = Color.Transparent,
                focusedIndicatorColor = Color(0xFF053FA5),
                unfocusedIndicatorColor = Color.LightGray,
                cursorColor = Color(0xFF053FA5),
                focusedTextColor = Color.Black,
                unfocusedTextColor = Color.Black,
            ),
            enabled = !isLoading
        )

        Spacer(Modifier.height(7.dp))

        // 비밀번호 입력
        PasswordField(
            password = password,
            onPasswordChange = { password = it },
            enabled = !isLoading
        )

        Spacer(Modifier.height(16.dp))

        // 에러 메시지
        errorMessage?.let { msg ->
            Text(
                text = msg,
                color = Color.Red,
                fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth(0.85f)
            )
            Spacer(Modifier.height(8.dp))
        }

        val canLogin = id.isNotBlank() && password.isNotBlank() && !isLoading

        // 로그인 버튼
        Button(
            onClick = {
                val username = id.trim().lowercase()
                val pw = password.trim()

                if (username.isEmpty() || pw.isEmpty()) {
                    errorMessage = "아이디와 비밀번호를 입력해 주세요."
                    return@Button
                }

                isLoading = true
                errorMessage = null

                // ✅ 1단계: usernames/{username}에서 uid + email 바로 가져오기
                store.collection("usernames")
                    .document(username)
                    .get()
                    .addOnSuccessListener { doc ->
                        if (!doc.exists()) {
                            isLoading = false
                            errorMessage = "존재하지 않는 아이디입니다."
                            return@addOnSuccessListener
                        }

                        val uid = doc.getString("uid")
                        val email = doc.getString("email")

                        if (uid.isNullOrBlank() || email.isNullOrBlank()) {
                            isLoading = false
                            errorMessage = "계정 정보에 오류가 있습니다."
                            return@addOnSuccessListener
                        }

                        // ✅ 2단계: email + pw로 Firebase Auth 로그인
                        auth.signInWithEmailAndPassword(email.trim(), pw)
                            .addOnCompleteListener { task ->
                                isLoading = false
                                if (task.isSuccessful) {
                                    // 로그인 성공 → home/{uid}로 이동
                                    navController.navigate("home/$uid") {
                                        popUpTo("login") { inclusive = true }
                                    }
                                } else {
                                    errorMessage = "로그인에 실패했습니다. 비밀번호를 확인해 주세요."
                                }
                            }
                    }
                    .addOnFailureListener {
                        isLoading = false
                        errorMessage = "아이디 조회 중 오류가 발생했습니다."
                    }
            },
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .height(52.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (canLogin) Color(0xFF053FA5) else Color(0xFFB0C4FF),
                contentColor = Color.White
            ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
            enabled = canLogin
        ) {
            Text(if (isLoading) "로그인 중..." else "로그인", fontSize = 18.sp)
        }

        Spacer(Modifier.height(5.dp))

        // 회원가입 텍스트 버튼
        val interaction = remember { MutableInteractionSource() }
        Text(
            text = "회원가입",
            fontSize = 18.sp,
            color = Color.LightGray,
            modifier = Modifier
                .padding(top = 8.dp)
                .clickable(
                    interactionSource = interaction,
                    indication = ripple(bounded = false),
                    role = Role.Button
                ) {
                    if (!isLoading) {
                        navController.navigate("signup_email")
                    }
                }
        )
    }
}

@Composable
fun PasswordField(
    password: String,
    onPasswordChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    var visible by rememberSaveable { mutableStateOf(false) }

    OutlinedTextField(
        value = password,
        onValueChange = onPasswordChange,
        placeholder = { Text("비밀번호를 입력하세요", color = Color.LightGray) },
        singleLine = true,
        visualTransformation = if (visible) VisualTransformation.None
        else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Password,
            imeAction = ImeAction.Done
        ),
        trailingIcon = {
            val icon = if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility
            val desc  = if (visible) "비밀번호 숨기기" else "비밀번호 보이기"
            IconButton(onClick = { visible = !visible }) {
                Icon(icon, contentDescription = desc, tint = Color.Gray)
            }
        },
        modifier = modifier
            .fillMaxWidth(0.85f)
            .height(52.dp),
        shape = RoundedCornerShape(12.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent,
            disabledContainerColor = Color.Transparent,
            focusedIndicatorColor = Color(0xFF053FA5),
            unfocusedIndicatorColor = Color.LightGray,
            cursorColor = Color(0xFF053FA5),
            focusedTextColor = Color.Black,
            unfocusedTextColor = Color.Black,
            disabledTextColor = Color.Gray
        ),
        enabled = enabled
    )
}

@Preview(showBackground = true)
@Composable
fun LoginScreenPreview() {
    SnowTimerAppTheme {
        val navController = rememberNavController()
        LoginScreen(navController = navController)
    }
}