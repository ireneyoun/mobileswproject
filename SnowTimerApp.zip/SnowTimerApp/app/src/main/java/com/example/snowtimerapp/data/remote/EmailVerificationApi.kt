package com.example.snowtimerapp.data.remote

import okhttp3.OkHttpClient
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

// Cloud Functions URL들
private const val SEND_CODE_BASE_URL =
    "https://sendverificationcode-pq7ftspw2a-uc.a.run.app/"
private const val VERIFY_CODE_BASE_URL =
    "https://verifycode-pq7ftspw2a-uc.a.run.app/"

// ----- 요청/응답 DTO -----

data class SendCodeRequest(
    val email: String
)

data class SendCodeResponse(
    val success: Boolean,
    val message: String?,
    val errorCode: String?
)

data class VerifyCodeRequest(
    val email: String,
    val code: String
)

data class VerifyCodeResponse(
    val success: Boolean,
    val message: String?,
    val verified: Boolean,
    val errorCode: String?
)

// ----- Retrofit 인터페이스 -----

interface EmailVerificationSendApi {
    @POST("/")   // baseUrl 루트에 POST
    suspend fun sendCode(
        @Body body: SendCodeRequest
    ): Response<SendCodeResponse>
}

interface EmailVerificationVerifyApi {
    @POST("/")
    suspend fun verifyCode(
        @Body body: VerifyCodeRequest
    ): Response<VerifyCodeResponse>
}

// ----- 생성 helper -----

object EmailVerificationApiFactory {

    // 🔹 타임아웃 여유 있게 준 OkHttpClient
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)   // 연결 시도 30초까지
            .readTimeout(30, TimeUnit.SECONDS)      // 응답 대기 30초까지
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    fun createSendApi(): EmailVerificationSendApi {
        val retrofit = Retrofit.Builder()
            .baseUrl(SEND_CODE_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        return retrofit.create(EmailVerificationSendApi::class.java)
    }

    fun createVerifyApi(): EmailVerificationVerifyApi {
        val retrofit = Retrofit.Builder()
            .baseUrl(VERIFY_CODE_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        return retrofit.create(EmailVerificationVerifyApi::class.java)
    }
}