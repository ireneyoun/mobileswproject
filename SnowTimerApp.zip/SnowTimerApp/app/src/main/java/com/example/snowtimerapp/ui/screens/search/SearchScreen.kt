package com.example.snowtimerapp.ui.screens.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.text.font.FontWeight.Companion.Bold
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.snowtimerapp.ui.components.BottomNavBar
import com.example.snowtimerapp.ui.components.MyTopAppBar
import com.example.snowtimerapp.ui.screens.home.TimerViewModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

// Firestore에서 가져올 과목 데이터 모델
data class Course(
    val section: String = "",
    val name: String = "",
    val professor: String = "",
    val code: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    navController: NavHostController,
    timerViewModel: TimerViewModel
) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("과목명") }

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val isInPreview = LocalInspectionMode.current
    val store: FirebaseFirestore? = if (isInPreview) null else remember { FirebaseFirestore.getInstance() }

    var allCourses by remember { mutableStateOf<List<Course>>(emptyList()) }
    var allLoaded by remember { mutableStateOf(false) }

    var results by remember { mutableStateOf<List<Course>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var searchExecuted by remember { mutableStateOf(false) }

    var previewInitialized by remember { mutableStateOf(false) }

    // ---------------- Firestore 로드 ----------------
    if (!allLoaded) {
        allLoaded = true
        if (isInPreview) {
            allCourses = listOf(
                Course("001", "알고리즘", "안태훈", "21000549"),
                Course("001", "데이터베이스설계와질의", "심준호", "21003183"),
                Course("001", "컴퓨터네트워크Ⅰ", "최종원", "21003186")
            )
        } else {
            isLoading = true
            store?.collection("courses")?.get()
                ?.addOnSuccessListener { snapshot ->
                    allCourses = snapshot.documents.mapNotNull { it.toObject(Course::class.java) }
                    isLoading = false
                }
                ?.addOnFailureListener { e ->
                    errorMessage = "과목 목록을 불러오는 중 오류: ${e.localizedMessage}"
                    isLoading = false
                }
        }
    }

    // ---------------- 검색 함수 ----------------
    fun runSearch() {
        val q = query.trim()
        if (q.isBlank()) {
            results = emptyList()
            errorMessage = null
            searchExecuted = false
            return
        }
        if (allCourses.isEmpty()) {
            errorMessage = "아직 과목 목록을 불러오는 중입니다."
            results = emptyList()
            searchExecuted = true
            return
        }

        isLoading = true
        errorMessage = null
        searchExecuted = true

        val filtered = allCourses.filter { course ->
            val target = when (selected) {
                "과목명" -> course.name
                "교수명" -> course.professor
                "과목 코드" -> course.code
                else -> course.name
            }
            target.contains(q, ignoreCase = true)
        }

        results = filtered
        isLoading = false
    }

    if (isInPreview && !previewInitialized && allCourses.isNotEmpty()) {
        previewInitialized = true
        query = "알고리즘"
        runSearch()
    }

    // ---------------- UI ----------------
    Scaffold(
        topBar = {
            Column {
                MyTopAppBar(title = "과목 검색")
                HorizontalDivider(color = Color.LightGray)
            }
        },
        bottomBar = {
            Column {
                HorizontalDivider(color = Color.LightGray)
                BottomNavBar(currentRoute = "search", navController = navController)
            }
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = Color.Black,   // 🔵 배경색
                    contentColor = Color.White,           // 🔹 글자색
                    shape = RoundedCornerShape(12.dp)     // 둥근 모서리
                )
            }
        },
        containerColor = Color.White
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(20.dp)
                .fillMaxSize()
        ) {
            // 🔍 검색 입력창
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFFEDEDED), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.CenterStart
                ) {
                    TextField(
                        value = query,
                        onValueChange = {
                            query = it
                            searchExecuted = false
                        },
                        placeholder = { Text("검색") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "검색",
                                tint = Color.Gray,
                                modifier = Modifier.padding(start = 10.dp)
                            )
                        },
                        modifier = Modifier
                            .background(Color.Transparent)
                            .fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent
                        )
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "검색",
                    color = Color.Gray,
                    modifier = Modifier.clickable { runSearch() }
                )
            }

            Spacer(modifier = Modifier.height(7.dp))

            // 🔘 라디오 버튼
            Row(
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioLabelItem("과목명", selected == "과목명") {
                    selected = "과목명"; if (query.isNotBlank()) runSearch()
                }
                Spacer(Modifier.width(14.dp))
                RadioLabelItem("교수명", selected == "교수명") {
                    selected = "교수명"; if (query.isNotBlank()) runSearch()
                }
                Spacer(Modifier.width(14.dp))
                RadioLabelItem("과목 코드", selected == "과목 코드") {
                    selected = "과목 코드"; if (query.isNotBlank()) runSearch()
                }
            }

            // 🔄 검색 결과
            when {
                isLoading -> Text("검색 중...", color = Color.Gray)
                errorMessage != null -> Text(errorMessage ?: "", color = Color.Red)
                searchExecuted -> {
                    if (results.isEmpty()) {
                        Text("검색 결과가 없습니다.", color = Color.Gray)
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)   // 남은 공간 스크롤 영역 확보
                        ) {
                            items(results) { course ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(course.name, fontSize = 16.sp, fontWeight = Bold)
                                            Spacer(modifier = Modifier.height(3.dp))
                                            Text("${course.professor}", fontSize = 14.sp)
                                            Text(
                                                "${course.code}-${course.section}",
                                                fontSize = 14.sp
                                            )
                                        }
                                        Button(
                                            onClick = {
                                                // 🔹 타이머에 추가
                                                timerViewModel.addCourseAsStudyItem(course)
                                                scope.launch {
                                                    snackbarHostState.showSnackbar(
                                                        message = "${course.name}이(가) 추가되었습니다.",
                                                        withDismissAction = false,
                                                        duration = SnackbarDuration.Short   // 🔹 짧게
                                                    )
                                                }
                                            },
                                            modifier = Modifier.height(36.dp),
                                            shape = RoundedCornerShape(15.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color.Black,
                                                contentColor = Color.White
                                            ),
                                            contentPadding = PaddingValues(
                                                vertical = 4.dp,
                                                horizontal = 12.dp
                                            )
                                        ) {
                                            Text("추가", fontSize = 14.sp)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    HorizontalDivider(color = Color(0xFFE0E0E0))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- Radio Button ----------------
@Composable
fun RadioLabelItem(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick,
            modifier = Modifier.scale(0.9f),
            colors = RadioButtonDefaults.colors(
                selectedColor = Color.Black,
                unselectedColor = Color.Gray
            )
        )
        Text(text = label)
    }
}

@Preview(showBackground = true)
@Composable
fun SearchScreenPreview() {
    val navController = rememberNavController()
    val dummyViewModel = TimerViewModel()
    SearchScreen(navController = navController, timerViewModel = dummyViewModel)
}