package com.example.snowtimerapp.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import com.example.snowtimerapp.R

// Variable 폰트 1개로 모든 웨이트 자동 적용 가능
val Pretendard = FontFamily(
    Font(
        resId = R.font.pretendard
    )
)

val Noto = FontFamily(
    Font(R.font.notoreg)
)

val Roboto = FontFamily(
    Font(R.font.roboto)
)
