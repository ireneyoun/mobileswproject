package com.example.snowtimerapp.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.google.firebase.auth.FirebaseAuth

data class BottomNavItem(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun BottomNavBar(
    currentRoute: String,
    navController: NavHostController,
    onItemClickBeforeNavigate: (BottomNavItem) -> Unit = {}
) {
    val items = listOf(
        BottomNavItem("home", "홈", Icons.Filled.Home),
        BottomNavItem("search", "검색", Icons.Filled.Search),
        BottomNavItem("group", "그룹", Icons.Filled.Group),
        BottomNavItem("settings", "설정", Icons.Filled.Settings)
    )

    NavigationBar(
        containerColor = Color.White,
        tonalElevation = 0.dp,
        modifier = Modifier.padding(horizontal = 8.dp)
    ) {
        items.forEach { item ->
            // ✅ 현재 선택된 탭인지 판별
            val isSelected = when (item.route) {
                "home" -> currentRoute.startsWith("home")   // home/{uid} 대응
                else   -> currentRoute == item.route
            }

            val iconColor =
                if (isSelected) Color.Black else Color.Gray

            NavigationBarItem(
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = iconColor,
                        modifier = Modifier.size(30.dp)
                    )
                },
                selected = isSelected,
                onClick = {
                    if (isSelected) return@NavigationBarItem

                    onItemClickBeforeNavigate(item)

                    val targetRoute = when (item.route) {
                        "home" -> {
                            // ✅ 여기서 uid 직접 가져오기
                            val uid = FirebaseAuth.getInstance().currentUser?.uid
                            if (uid != null) {
                                "home/$uid"
                            } else {
                                // 로그인 안 되어 있으면 로그인 화면으로
                                "login"
                            }
                        }
                        else -> item.route
                    }

                    navController.navigate(targetRoute) {
                        launchSingleTop = true
                        popUpTo(navController.graph.startDestinationId) {
                            saveState = true
                        }
                        restoreState = true
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    unselectedIconColor = Color.Gray,
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}