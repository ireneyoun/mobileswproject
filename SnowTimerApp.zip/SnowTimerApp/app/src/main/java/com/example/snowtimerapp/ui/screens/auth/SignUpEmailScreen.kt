package com.example.snowtimerapp.ui.screens.auth

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontWeight.Companion.Bold
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.snowtimerapp.data.remote.EmailVerificationApiFactory
import com.example.snowtimerapp.data.remote.SendCodeRequest
import com.example.snowtimerapp.data.remote.VerifyCodeRequest
import com.example.snowtimerapp.ui.components.MyTopAppBar
import com.example.snowtimerapp.ui.theme.SnowTimerAppTheme
import kotlinx.coroutines.launch

@Composable
fun SignUpEmailScreen(navController: NavController, startWithCodeStep: Boolean = false) {
    val scope = rememberCoroutineScope()

    // Retrofit API 인스턴스
    val sendApi = remember { EmailVerificationApiFactory.createSendApi() }
    val verifyApi = remember { EmailVerificationApiFactory.createVerifyApi() }

    // UI 상태
    var email by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }

    var isDomainValid by remember { mutableStateOf(true) }
    var isCodeSent by remember { mutableStateOf(startWithCodeStep) }
    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    // --- 인증코드 전송 ---
    fun sendCode() {
        val target = email.trim()

        if (target.isEmpty()) {
            isError = true
            return
        }
        if (!target.endsWith("@sookmyung.ac.kr")) {
            isDomainValid = false
            isError = true
            return
        }

        isDomainValid = true
        isLoading = true
        isError = false

        scope.launch {
            try {
                val resp = sendApi.sendCode(SendCodeRequest(email = target))
                Log.d("SignUpEmail", "sendCode response: ${resp.code()} ${resp.message()}")

                if (resp.isSuccessful) {
                    val body = resp.body()
                    Log.d("SignUpEmail", "sendCode body: $body")

                    if (body?.success == true) {
                        isCodeSent = true
                        isError = false
                    } else {
                        isError = true
                    }
                } else {
                    isError = true
                }
            } catch (e: Exception) {
                Log.e("SignUpEmail", "sendCode 호출 중 예외 발생", e)
                isError = true
            } finally {
                isLoading = false
            }
        }
    }

    // --- 인증코드 검증 후 다음 화면으로 이동 ---
    fun verifyCodeAndNext() {
        val target = email.trim()
        val inputCode = code.trim()

        if (target.isEmpty() || inputCode.isEmpty()) {
            isError = true
            return
        }

        isLoading = true
        statusMessage = null
        isError = false

        scope.launch {
            try {
                val resp = verifyApi.verifyCode(
                    VerifyCodeRequest(email = target, code = inputCode)
                )
                if (resp.isSuccessful) {
                    val body = resp.body()
                    if (body?.success == true && body.verified) {
                        isError = false

                        // 다음 단계에서 사용할 이메일 저장
                        navController.currentBackStackEntry
                            ?.savedStateHandle
                            ?.set("email", target)

                        navController.navigate("signup_school")
                    } else {
                        isError = true
                    }
                } else {
                    isError = true
                }
            } catch (e: Exception) {
                isError = true
            } finally {
                isLoading = false
            }
        }
    }

    // --- UI ---
    Scaffold(
        containerColor = Color.White,
        topBar = {
            Column {
                MyTopAppBar(title = "회원가입")
                Divider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(50.dp))

            // 상단 타이틀은 단계에 따라 문구만 살짝 변경
            Text(
                text = if (!isCodeSent) "이메일을 입력해 주세요"
                else "이메일로 받은 코드를 입력해 주세요",
                fontWeight = Bold,
                fontSize = 19.sp
            )

            Spacer(Modifier.height(40.dp))

            // =========================
            // 1단계: 이메일 입력 + 전송 버튼
            // 2단계: 코드 입력 + 확인 버튼
            // 같은 위치에서 갈아끼우기
            // =========================

            if (!isCodeSent) {
                // ---------- 이메일 입력 영역 ----------
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                start = 0.dp,
                                top = 8.dp,
                                bottom = 8.dp,
                                end = 0.dp
                            )
                    ) {
                        if (email.isEmpty()) {
                            Text(
                                text = "example@sookmyung.ac.kr",
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                modifier = Modifier.align(Alignment.CenterStart)
                            )
                        }

                        BasicTextField(
                            value = email,
                            onValueChange = {
                                email = it
                                isDomainValid = it.endsWith("@sookmyung.ac.kr")
                            },
                            textStyle = LocalTextStyle.current.copy(
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.CenterStart)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(
                                if (isDomainValid || email.isEmpty())
                                    MaterialTheme.colorScheme.outlineVariant
                                else
                                    Color(0xFF053FA5)
                            )
                    )
                }

                if (!isDomainValid && email.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "숙명 메일(@sookmyung.ac.kr)만 사용 가능합니다.",
                        color = Color(0xFF053FA5),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(Modifier.height(80.dp))

                val isEmailValid = email.isNotBlank()

                Button(
                    onClick = { if (!isLoading) sendCode() },
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .fillMaxWidth(0.85f)
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF053FA5),
                        contentColor = Color.White
                    ),
                    enabled = isEmailValid && !isLoading
                ) {
                    if (isLoading) {
                        Text("전송 중...", fontSize = 18.sp)
                    } else {
                        Text("인증 코드 전송", fontSize = 18.sp)
                    }
                }
            } else {
                // ---------- 코드 입력 영역 (이메일이랑 동일한 스타일) ----------
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                start = 0.dp,
                                top = 8.dp,
                                bottom = 8.dp,
                                end = 0.dp
                            )
                    ) {
                        if (code.isEmpty()) {
                            Text(
                                text = "6자리 코드 (대문자 + 숫자)",
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                modifier = Modifier.align(Alignment.CenterStart)
                            )
                        }

                        BasicTextField(
                            value = code,
                            onValueChange = { code = it.uppercase() },
                            textStyle = LocalTextStyle.current.copy(
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.CenterStart)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(
                                MaterialTheme.colorScheme.outlineVariant
                            )
                    )
                }

                Spacer(Modifier.height(80.dp))

                val canVerify = code.length == 6

                Button(
                    onClick = { if (!isLoading) verifyCodeAndNext() },
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .fillMaxWidth(0.85f)
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF053FA5),
                        contentColor = Color.White
                    ),
                    enabled = canVerify && !isLoading
                ) {
                    if (isLoading) {
                        Text("인증 중...", fontSize = 18.sp)
                    } else {
                        Text("확인", fontSize = 18.sp)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            statusMessage?.let { msg ->
                Text(
                    text = msg,
                    color = if (isError) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun EmailPreview() {
    SnowTimerAppTheme {
        val navController = rememberNavController()
        SignUpEmailScreen(navController = navController,
            startWithCodeStep = false)
    }
}

@Preview(showBackground = true)
@Composable
fun EmailPreview_CodeStep() {
    SnowTimerAppTheme {
        val navController = rememberNavController()
        SignUpEmailScreen(
            navController = navController,
            startWithCodeStep = true    // 👈 코드 입력 화면 상태
        )
    }
}