package com.example.snowtimerapp.ui.screens.search

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore

fun seedSubjectsOnce() {
    val db = FirebaseFirestore.getInstance()
    val batch = db.batch()

    dummySubjects.forEach { s ->
        // 문서 id를 과목 코드로 사용 (중복 방지)
        val docId = "${s.code}_${s.section}"
        val docRef = db.collection("courses").document(docId)

        val data = mapOf(
            "name" to s.name,
            "professor" to s.professor,
            "code" to s.code,
            "section" to s.section
        )

        batch.set(docRef, data)
    }

    batch.commit()
        .addOnSuccessListener {
            Log.d("SeedSubjects", "✅ 과목 더미 데이터 삽입 완료")
        }
        .addOnFailureListener { e ->
            Log.e("SeedSubjects", "❌ 과목 삽입 실패", e)
        }
}

// 예시용 데이터 클래스 (굳이 안써도 되지만 보기 편해서)
data class Subject(
    val name: String,
    val professor: String,
    val code: String,
    val section: String
)

// 한 번에 넣을 과목들 리스트
val dummySubjects = listOf(
    Subject(
        name = "AI수학",
        professor = "박수현",
        code = "21105367",
        section = "001"
    ),
    Subject(
        name = "데이터마이닝및분석",
        professor = "이기용",
        code = "21102905",
        section = "001"
    ),
    Subject(
        name = "딥러닝개론",
        professor = "홍기범",
        code = "21105625",
        section = "001"
    ),
    Subject(
        name = "파이썬데이터분석",
        professor = "홍기범",
        code = "21105229",
        section = "001"
    ),
    Subject(
        name = "경영정보시스템",
        professor = "한은정",
        code = "21001083",
        section = "002"
    ),
    Subject(
        name = "경영정보시스템",
        professor = "한은정",
        code = "21001083",
        section = "003"
    ),
    Subject(
        name = "경영정보시스템",
        professor = "한은정",
        code = "21001083",
        section = "004"
    ),
    Subject(
        name = "네트워크보안",
        professor = "박영훈",
        code = "21002031",
        section = "001"
    ),
    Subject(
        name = "데이터베이스설계와질의",
        professor = "심준호",
        code = "21003183",
        section = "001"
    ),
    Subject(
        name = "데이터베이스설계와질의",
        professor = "심준호",
        code = "21003183",
        section = "002"
    ),
    Subject(
        name = "데이터베이스설계와질의",
        professor = "심준호",
        code = "21003183",
        section = "003"
    ),
    Subject(
        name = "리눅스시스템",
        professor = "창병모",
        code = "21001713",
        section = "001"
    ),
    Subject(
        name = "리눅스시스템",
        professor = "창병모",
        code = "21001713",
        section = "002"
    ),
    Subject(
        name = "소프트웨어의이해",
        professor = "최영우",
        code = "21003917",
        section = "001"
    ),
    Subject(
        name = "알고리즘",
        professor = "안태훈",
        code = "21000549",
        section = "001"
    ),
    Subject(
        name = "알고리즘",
        professor = "안태훈",
        code = "21000549",
        section = "002"
    ),
    Subject(
        name = "인공지능산업체특강",
        professor = "이종우",
        code = "21105589",
        section = "001"
    ),
    Subject(
        name = "자바프로그래밍",
        professor = "창병모",
        code = "21000557",
        section = "001"
    ),
    Subject(
        name = "자바프로그래밍",
        professor = "박숙영",
        code = "21000557",
        section = "002"
    ),
    Subject(
        name = "자바프로그래밍",
        professor = "박숙영",
        code = "21000557",
        section = "003"
    ),
    Subject(
        name = "컴퓨터그래픽스",
        professor = "정영주",
        code = "21000558",
        section = "001"
    ),
    Subject(
        name = "컴퓨터그래픽스",
        professor = "정영주",
        code = "21000558",
        section = "002"
    ),
    Subject(
        name = "컴퓨터수학",
        professor = "채희준",
        code = "21002147",
        section = "001"
    ),
    Subject(
        name = "컴퓨터수학",
        professor = "최영우",
        code = "21002147",
        section = "002"
    ),
    Subject(
        name = "컴퓨터수학",
        professor = "최영우",
        code = "21002147",
        section = "003"
    ),
    Subject(
        name = "클라우드시스템",
        professor = "김윤희, 김서영",
        code = "21003735",
        section = "001"
    ),
    Subject(
        name = "프로그래밍개론",
        professor = "조선영",
        code = "21002144",
        section = "001"
    ),
    Subject(
        name = "프로그래밍개론",
        professor = "조선영",
        code = "21002144",
        section = "002"
    ),
    Subject(
        name = "프로그래밍개론",
        professor = "박수현",
        code = "21002144",
        section = "003"
    ),
    Subject(
        name = "학생개설:지능형언어처리",
        professor = "김철연",
        code = "21105395",
        section = "001"
    ),
    Subject(
        name = "논리및논술(정보·컴퓨터)",
        professor = "이현자",
        code = "21009627",
        section = "001"
    ),
    Subject(
        name = "디지털논리회로",
        professor = "박영훈",
        code = "21001710",
        section = "001"
    ),
    Subject(
        name = "디지털논리회로",
        professor = "박영훈",
        code = "21001710",
        section = "002"
    ),
    Subject(
        name = "소프트웨어공학",
        professor = "김유경",
        code = "21000555",
        section = "001"
    ),
    Subject(
        name = "영상정보처리",
        professor = "정영주",
        code = "21003187",
        section = "001"
    ),
    Subject(
        name = "정보·컴퓨터교재연구및지도)",
        professor = "이현자",
        code = "21050161",
        section = "001"
    ),
    Subject(
        name = "컴퓨터네트워크Ⅰ",
        professor = "최종원",
        code = "21003186",
        section = "001"
    ),
    Subject(
        name = "컴퓨터네트워크Ⅰ",
        professor = "최종원",
        code = "21003186",
        section = "002"
    )
)