package com.example.snowtimerapp.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontWeight.Companion.Bold
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.snowtimerapp.ui.components.MyTopAppBar
import com.example.snowtimerapp.ui.theme.SnowTimerAppTheme

@Composable
fun SignUpSchoolScreen(navController: NavController) {
    var std by remember { mutableStateOf("") }
    var major by remember { mutableStateOf("") }

    Scaffold(
        containerColor = Color.White,
        topBar = {
            Column {
                MyTopAppBar(title = "회원가입")
                HorizontalDivider(color = Color.LightGray)
            }
        }
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
        ) {

            Spacer(Modifier.height(50.dp))

            Text(
                text = "학번과 전공을 입력해 주세요",
                fontWeight = Bold,
                fontSize = 19.sp
            )

            Spacer(Modifier.height(40.dp))

            // 학번
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "학번",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium
                )

                Column(
                    modifier = Modifier
                        .padding(start = 15.dp)
                        .fillMaxWidth()
                ) {
                    BasicTextField(
                        value = std,
                        onValueChange = { std = it },
                        singleLine = true,
                        textStyle = LocalTextStyle.current.copy(
                            fontSize = 17.sp,
                            color = Color.Black
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // 밑줄
                    Spacer(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(
                                when {
                                    std.isNotBlank() -> Color(0xFF053FA5)
                                    else -> MaterialTheme.colorScheme.outlineVariant
                                }
                            )
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // 🔹 전공 (드롭다운)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "전공",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 15.dp)
                ) {
                    var expanded by remember { mutableStateOf(false) }

                    // 원하는 전공 목록 여기서 수정
                    val majorGroups = listOf(
                        listOf(
                            "한국어문학부", "역사문화학과", "프랑스언어·문화학과", "중어중문학부", "독일언어·문화학과",
                            "일본학과", "문헌정보학과", "문화관광학전공", "르꼬르동블루외식경영전공", "교육학부"
                        ),
                        listOf("가족자원경영학과", "아동복지학부"),
                        listOf("정치외교학과", "행정학과", "홍보광고학과", "소비자경제학과", "사회심리학과"),
                        listOf("법학부"),
                        listOf("경제학부", "경영학부"),
                        listOf("글로벌협력전공", "앙트러프러너십전공"),
                        listOf("영어영문학전공", "테슬(TESL)전공"),
                        listOf("미디어학부"),
                        listOf("화학과", "생명시스템학부", "수학과", "통계학과"),
                        listOf(
                            "화공생명공학부",
                            "인공지능공학부",
                            "지능형전자시스템학부",
                            "신소재물리학부",
                            "컴퓨터과학전공",
                            "데이터사이언스전공",
                            "기계시스템학부",
                            "첨단공학부"
                        ),
                        listOf("의류학과", "식품영양학과"),
                        listOf("약학부"),
                        listOf("자유전공학부")
                    )

                    // 선택 박스 (iOS 느낌 나는 흰색 카드)
                    Box(
                        modifier = Modifier
                            .height(52.dp)
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .clickable { expanded = true },
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (major.isBlank()) "선택" else major,
                                fontSize = 17.sp,
                                color = if (major.isBlank()) Color.Gray else Color.Black
                            )

                            Spacer(modifier = Modifier.weight(1f))

                            // 아래 화살표 아이콘 느낌 (직접 아이콘 쓰고 싶으면 Icon으로 교체 가능)
                            Icon(
                                imageVector = if (expanded)
                                    androidx.compose.material.icons.Icons.Filled.ExpandLess
                                else
                                    androidx.compose.material.icons.Icons.Filled.ExpandMore,
                                contentDescription = null,
                                tint = Color.Gray
                            )
                        }
                    }

                    // 드롭다운 메뉴
                    androidx.compose.material3.DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.heightIn(max = 300.dp).background(Color.White),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        majorGroups.forEachIndexed { groupIndex, groupList ->

                            groupList.forEach { majorItem ->
                                DropdownMenuItem(
                                    text = { Text(majorItem, fontSize = 16.sp) },
                                    onClick = {
                                        major = majorItem
                                        expanded = false
                                    }
                                )
                            }

                            // 🔹 마지막 그룹이 아니라면 Divider 넣기
                            if (groupIndex < majorGroups.lastIndex) {
                                Divider(
                                    color = Color.LightGray,
                                    thickness = 1.dp,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(80.dp))

            Button(
                onClick = {
                    // 🔥 현재 Route("signup_school")의 handle에 정확히 저장
                    val schoolEntry = navController.getBackStackEntry("signup_school")
                    schoolEntry.savedStateHandle["studentId"] = std
                    schoolEntry.savedStateHandle["major"] = major

                    // 다음 화면 이동
                    navController.navigate("signup_id")
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF053FA5),
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .fillMaxWidth(0.85f)
                    .height(52.dp),
            ) {
                Text(
                    text = "확인",
                    fontSize = 18.sp
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SignUpSchoolPreview() {
    SnowTimerAppTheme {
        val navController = rememberNavController()
        SignUpSchoolScreen(navController)
    }
}