package com.example.snowtimerapp.ui.theme

import androidx.compose.material3.Typography

// 기본 폰트를 Pretendard로 전체 적용
val AppTypography = Typography(
    displayLarge = Typography().displayLarge.copy(fontFamily = Pretendard),
    displayMedium = Typography().displayMedium.copy(fontFamily = Pretendard),
    displaySmall = Typography().displaySmall.copy(fontFamily = Pretendard),
    headlineLarge = Typography().headlineLarge.copy(fontFamily = Pretendard),
    headlineMedium = Typography().headlineMedium.copy(fontFamily = Pretendard),
    headlineSmall = Typography().headlineSmall.copy(fontFamily = Pretendard),
    titleLarge = Typography().titleLarge.copy(fontFamily = Pretendard),
    titleMedium = Typography().titleMedium.copy(fontFamily = Pretendard),
    titleSmall = Typography().titleSmall.copy(fontFamily = Pretendard),
    bodyLarge = Typography().bodyLarge.copy(fontFamily = Pretendard),
    bodyMedium = Typography().bodyMedium.copy(fontFamily = Pretendard),
    bodySmall = Typography().bodySmall.copy(fontFamily = Pretendard),
    labelLarge = Typography().labelLarge.copy(fontFamily = Pretendard),
    labelMedium = Typography().labelMedium.copy(fontFamily = Pretendard),
    labelSmall = Typography().labelSmall.copy(fontFamily = Pretendard)
)