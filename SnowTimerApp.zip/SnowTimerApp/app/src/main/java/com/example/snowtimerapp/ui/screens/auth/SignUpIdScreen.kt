package com.example.snowtimerapp.ui.screens.auth

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.snowtimerapp.data.repo.AuthRepository
import com.example.snowtimerapp.ui.components.MyTopAppBar
import com.example.snowtimerapp.ui.theme.SnowTimerAppTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class IdCheckState { Idle, Checking, Ok, Taken, Error }

@SuppressLint("UnrememberedGetBackStackEntry")
@Composable
fun SignUpIdScreen(navController: NavController) {

    val isPreview = LocalInspectionMode.current

    // 🔹 signup_email / signup_school 에서 온 값들
    val email: String
    val studentId: String
    val major: String

    if (isPreview) {
        // ✅ 프리뷰용 더미 데이터
        email = "test@sookmyung.ac.kr"
        studentId = "20231234"
        major = "컴퓨터과학전공"
    } else {
        // ✅ 실제 런타임용: navController에서 읽기
        val emailEntry = try { navController.getBackStackEntry("signup_email") } catch (e: Exception) { null }
        val schoolEntry = try { navController.getBackStackEntry("signup_school") } catch (e: Exception) { null }

        email = emailEntry?.savedStateHandle?.get<String>("email") ?: ""
        studentId = schoolEntry?.savedStateHandle?.get<String>("studentId") ?: ""
        major = schoolEntry?.savedStateHandle?.get<String>("major") ?: ""
    }

    // 🔹 입력값 상태
    var nickname by remember { mutableStateOf("") }
    var id by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    // 🔹 UI 상태
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // 🔹 ID 중복 체크
    val scope = rememberCoroutineScope()
    var idCheckState by remember { mutableStateOf(IdCheckState.Idle) }
    var debounce: Job? by remember { mutableStateOf(null) }

    // 🔹 AuthRepository (프리뷰에서는 null로 둠)
    val repo: AuthRepository? = if (!isPreview) {
        remember {
            AuthRepository(
                auth = FirebaseAuth.getInstance(),
                store = FirebaseFirestore.getInstance()
            )
        }
    } else {
        null
    }

    fun checkIdAvailability(username: String) {
        if (username.isBlank()) {
            idCheckState = IdCheckState.Idle
            return
        }
        idCheckState = IdCheckState.Checking

        debounce?.cancel()
        debounce = scope.launch {
            delay(400)
            try {
                val ok = repo?.isUsernameAvailable(username) ?: true   // 프리뷰에선 그냥 가능하다고 가정
                idCheckState = if (ok) IdCheckState.Ok else IdCheckState.Taken
            } catch (_: Exception) {
                idCheckState = IdCheckState.Error
            }
        }
    }

    Scaffold(
        containerColor = Color.White,
        topBar = {
            Column {
                MyTopAppBar(title = "회원가입")
                HorizontalDivider(color = Color.LightGray)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
        ) {

            Spacer(Modifier.height(50.dp))

            Text(
                text = "회원 정보를 입력해 주세요",
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp
            )

            Spacer(Modifier.height(40.dp))

            // 닉네임
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "닉네임",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(74.dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                start = 0.dp,
                                top = 5.dp,
                                bottom = 5.dp,
                                end = 0.dp
                            )
                    ) {
                        BasicTextField(
                            value = nickname,
                            onValueChange = { nickname = it },
                            textStyle = LocalTextStyle.current.copy(
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.CenterStart)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(
                                if (nickname.isNotBlank())
                                    Color(0xFF053FA5)
                                else
                                    MaterialTheme.colorScheme.outlineVariant
                            )
                    )
                }
            }


            Spacer(Modifier.height(10.dp))

            // 아이디
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "아이디",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(74.dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                start = 0.dp,
                                top = 5.dp,
                                bottom = 5.dp,
                                end = 0.dp
                            )
                    ) {
                        BasicTextField(
                            value = id,
                            onValueChange = { new ->
                                val username = new.trim().lowercase()
                                id = username
                                checkIdAvailability(username)
                            },
                            textStyle = LocalTextStyle.current.copy(
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.CenterStart),
                            decorationBox = { inner ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(modifier = Modifier.weight(1f)) { inner() }

                                    when (idCheckState) {
                                        IdCheckState.Checking ->
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp),
                                                strokeWidth = 2.dp
                                            )
                                        IdCheckState.Ok ->
                                            Text("사용 가능한 아이디", color = Color(0xFF0BAD12), fontSize = 12.sp)
                                        IdCheckState.Taken ->
                                            Text("사용 중인 아이디", color = Color(0xFFE10303), fontSize = 12.sp)
                                        IdCheckState.Error ->
                                            Text("오류 발생", color = Color(0xFFFF5722), fontSize = 12.sp)
                                        else -> {}
                                    }
                                }
                            }
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(
                                if (id.isNotBlank() && idCheckState == IdCheckState.Ok)
                                    Color(0xFF053FA5)
                                else
                                    MaterialTheme.colorScheme.outlineVariant
                            )
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            var passwordVisible by remember { mutableStateOf(false) }

            // 비밀번호
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "비밀번호",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(74.dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                start = 0.dp,
                                top = 5.dp,
                                bottom = 5.dp,
                                end = 0.dp
                            )
                    ) {
                        BasicTextField(
                            value = password,
                            onValueChange = { password = it },
                            textStyle = LocalTextStyle.current.copy(
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            singleLine = true,
                            visualTransformation = if (passwordVisible)
                                VisualTransformation.None
                            else
                                PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.CenterStart),
                            decorationBox = { innerTextField ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {

                                    // 입력 영역
                                    Box(modifier = Modifier.weight(1f)) {
                                        innerTextField()
                                    }

                                    // 👁 아이콘
                                    Icon(
                                        imageVector =
                                            if (passwordVisible)
                                                Icons.Filled.Visibility
                                            else
                                                Icons.Filled.VisibilityOff,
                                        contentDescription = null,
                                        tint = Color.Gray,
                                        modifier = Modifier
                                            .size(25.dp)
                                            .padding(start = 8.dp)
                                            .clickable {
                                                passwordVisible = !passwordVisible
                                            }
                                    )
                                }
                            }
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(
                                if (password.isNotBlank())
                                    Color(0xFF053FA5)
                                else
                                    MaterialTheme.colorScheme.outlineVariant
                            )
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            // 에러 메시지
            errorMessage?.let { msg ->
                Text(
                    text = msg,
                    color = Color(0xFFC62828),
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
            }

            // 🔹 버튼 활성 조건
            val canSubmit =
                nickname.isNotBlank() &&
                        id.isNotBlank() &&
                        password.length >= 6 &&
                        idCheckState == IdCheckState.Ok &&
                        email.isNotBlank() &&
                        studentId.isNotBlank() &&
                        major.isNotBlank()

            Spacer(Modifier.height(80.dp))

            Button(
                onClick = {
                    if (isSubmitting) return@Button

                    if (isPreview) {
                        errorMessage = "프리뷰 모드에서는 실제 회원가입이 실행되지 않습니다."
                        return@Button
                    }

                    if (email.isBlank() || studentId.isBlank() || major.isBlank()) {
                        errorMessage = "이메일/학번/전공 정보가 없습니다. 처음부터 다시 진행해 주세요."
                        return@Button
                    }

                    val realRepo = repo ?: run {
                        errorMessage = "Auth 설정 오류입니다."
                        return@Button
                    }

                    isSubmitting = true
                    errorMessage = null

                    scope.launch {
                        try {
                            // 1) Firebase Auth 계정 생성
                            val user = realRepo.createEmailAccount(email, password)
                            val uid = user.uid

                            // 2) username 점유 + Firestore 프로필 저장
                            realRepo.reserveUsernameAndCreateProfile(
                                uid = uid,
                                username = id,
                                nickname = nickname,
                                email = email,
                                studentId = studentId,
                                major = major
                            )

                            // 완료 후 로그인 화면으로 이동
                            navController.navigate("login") {
                                popUpTo("login") { inclusive = false }
                            }

                        } catch (e: Exception) {
                            errorMessage = when (e.message) {
                                "USERNAME_TAKEN" -> "이미 사용 중인 아이디입니다."
                                else -> "회원가입 중 오류가 발생했습니다."
                            }
                        } finally {
                            isSubmitting = false
                        }
                    }
                },
                enabled = canSubmit && !isSubmitting,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF053FA5),
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .fillMaxWidth(0.85f)
                    .height(52.dp),
            ) {
                Text(
                    text = if (isSubmitting) "생성 중..." else "계정 생성",
                    fontSize = 18.sp
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SignUpIdPreview() {
    SnowTimerAppTheme {
        val navController = rememberNavController()
        SignUpIdScreen(navController = navController)
    }
}