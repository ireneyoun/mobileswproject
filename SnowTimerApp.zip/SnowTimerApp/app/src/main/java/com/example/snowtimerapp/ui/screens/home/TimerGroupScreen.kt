package com.example.snowtimerapp.ui.screens.home

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun TimerGroupScreen() {
    Text(
        text = "그룹별 화면"
    )
}