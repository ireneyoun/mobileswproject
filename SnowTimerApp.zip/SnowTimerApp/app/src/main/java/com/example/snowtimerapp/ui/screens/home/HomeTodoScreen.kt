package com.example.snowtimerapp.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// -------------------------
// 메인 Todo 리스트 화면
// -------------------------
@Composable
fun HomeTodoScreen(
    studyItems: List<StudyItem>,
    onUpdateItems: (List<StudyItem>) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(studyItems) { item ->
            TodoItem(
                item = item,
                onUpdateItem = { updated ->
                    val newList = studyItems.map {
                        if (it.title == item.title) updated else it
                    }
                    onUpdateItems(newList)
                }
            )
        }
    }
}

// -------------------------
// 단일 과목 Todo 블록
// -------------------------
@Composable
fun TodoItem(
    item: StudyItem,
    onUpdateItem: (StudyItem) -> Unit,
    initialShowInput: Boolean = false
) {
    var showInput by remember { mutableStateOf(initialShowInput) }
    var text by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {

        // -------------------- 상단 바 --------------------
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            // + 버튼
            IconButton(
                onClick = { showInput = !showInput },
                modifier = Modifier
                    .padding(10.dp)
                    .size(30.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .background(Color.Black, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = "Add Todo",
                        tint = Color.White,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }

            Text(
                text = item.title,
                fontSize = 20.sp
            )

            Spacer(Modifier.weight(1f))

            // 접기/펼치기 버튼
            IconButton(onClick = { expanded = !expanded }) {
                Icon(
                    Icons.Default.KeyboardArrowDown,
                    contentDescription = "fold",
                    modifier = Modifier.rotate(if (expanded) 0f else -90f)
                )
            }
        }

        // -------------------- 입력창 --------------------
        if (showInput) {
            Column(
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(start = 50.dp)
                ) {
                    // ⬇ 밑줄 스타일 입력창
                    Column(
                        modifier = Modifier
                            .width(250.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(
                                    start = 0.dp,
                                    top = 0.dp,
                                    bottom = 5.dp,
                                    end = 0.dp
                                )
                        ) {
                            BasicTextField(
                                value = text,
                                onValueChange = { text = it },
                                textStyle = LocalTextStyle.current.copy(
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                ),
                                singleLine = true,
                                modifier = Modifier
                                    .align(Alignment.CenterStart),
                                decorationBox = { innerTextField ->
                                    if (text.isEmpty()) {
                                        Text(
                                            text = "To-do를 입력하세요",
                                            fontSize = 16.sp,
                                            color = Color.Gray
                                        )
                                    }
                                    innerTextField()
                                }
                            )
                        }

                        Box(
                            modifier = Modifier
                                .width(260.dp)
                                .height(1.dp)
                                .background(
                                    Color.Gray
                                )
                        )
                    }

                    Spacer(modifier = Modifier.width(13.dp))

                    Box(modifier = Modifier.height(35.dp).width(50.dp)) {
                        Button(
                            onClick = {
                                if (text.isNotBlank()) {
                                    val newList = (item.todos + Todo(text = text)).toMutableList()
                                    onUpdateItem(item.copy(todos = newList))
                                    text = ""
                                    showInput = false }
                            },
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.Black,
                                contentColor = Color.White
                            )
                        ) {
                            Text("ADD", fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        // -------------------- Todo 리스트 --------------------
        if (expanded) {
            item.todos.forEach { todo ->
                // 이 Todo 한 줄에 대한 상태 (체크 여부, 보이는지 여부)
                var checked by remember(todo) { mutableStateOf(false) }
                var visible by remember(todo) { mutableStateOf(true) }

                AnimatedVisibility(
                    visible = visible,
                    exit = fadeOut()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 35.dp)
                    ) {
                        Checkbox(
                            checked = checked,
                            onCheckedChange = { isChecked ->
                                checked = isChecked
                                if (isChecked) {
                                    scope.launch {
                                        // 잠깐 회색+취소선 상태 유지
                                        delay(1000)
                                        // 화면에서 사라지게
                                        visible = false
                                        // 실제 데이터에서도 제거
                                        val finalList = item.todos
                                            .filterNot { it == todo }
                                            .toMutableList()
                                        onUpdateItem(item.copy(todos = finalList))
                                    }
                                }
                            },
                            colors = CheckboxDefaults.colors(
                                checkedColor = Color.Black,       // 체크박스 체크될 때 배경색
                                uncheckedColor = Color.Black,            // 체크 안 됐을 때 테두리색
                                checkmarkColor = Color.White,           // 체크 표시(✓) 색
                                disabledCheckedColor = Color.Gray,
                                disabledUncheckedColor = Color.Gray
                            )
                        )

                        Text(
                            text = todo.text,
                            fontSize = 18.sp,
                            style = if (checked) {
                                TextStyle(
                                    color = Color.Gray,
                                    textDecoration = TextDecoration.LineThrough
                                )
                            } else {
                                TextStyle(color = Color.Black)
                            }
                        )
                    }
                }
            }
        }
    }
}

// -------------------------
// 프리뷰
// -------------------------
@Preview(showBackground = true)
@Composable
fun HomeTodoScreenPreview() {
    val sampleItems = listOf(
        StudyItem(
            title = "알고리즘",
            todos = mutableListOf(
                Todo("문제 3개 풀기"),
                Todo("강의 듣기")
            )
        ),
        StudyItem(
            title = "모바일소프트웨어",
            todos = mutableListOf(
                Todo("UI 구조 설계"),
                Todo("리포트 초안 작성")
            )
        )
    )

    HomeTodoScreen(
        studyItems = sampleItems,
        onUpdateItems = {}
    )
}

@Preview(showBackground = true)
@Composable
fun TodoItemPreview() {
    val sampleItem = StudyItem(
        title = "알고리즘",
        todos = mutableListOf()   // ✅ 투두 리스트는 비워두고
    )

    TodoItem(
        item = sampleItem,
        onUpdateItem = {},
        initialShowInput = true   // ✅ 시작할 때 입력창 열어두기
    )
}