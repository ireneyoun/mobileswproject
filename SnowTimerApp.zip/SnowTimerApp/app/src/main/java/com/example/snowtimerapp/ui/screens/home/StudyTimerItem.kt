package com.example.snowtimerapp.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.snowtimerapp.ui.theme.Noto

@Composable
fun StudyTimerItem(
    textColor: Color,
    item: StudyItem,
    onPlay: (() -> Unit)? = null,
    onDelete: () -> Unit = {},
    initialShowDialog: Boolean = false,
    onNavigateGroup: () -> Unit = {}
) {
    var showDialog by remember { mutableStateOf(initialShowDialog) }
    val density = LocalDensity.current
    var offsetXPx by remember { mutableStateOf(0f) }
    val maxSwipePx = with(density) { 100.dp.toPx() }
    val animatedOffsetDp = with(density) {
        animateFloatAsState(offsetXPx).value.toDp()
    }
    val isButtonVisible = offsetXPx <= -maxSwipePx / 2f

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
    ) {
        AnimatedVisibility(
            visible = isButtonVisible,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .zIndex(1f)
                .fillMaxHeight()
                .background(Color.Gray)
                .clickable {
                    showDialog = true
                }
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxHeight()
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = "삭제",
                    fontSize = 16.sp,
                    color = Color.White
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .offset(x = animatedOffsetDp)
                .zIndex(0f)
                .background(Color.White)
                .pointerInput(item) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            offsetXPx = if (offsetXPx < -maxSwipePx / 2f) -maxSwipePx else 0f
                        },
                        onHorizontalDrag = { change, dragAmount ->
                            offsetXPx = (offsetXPx + dragAmount)
                                .coerceIn(-maxSwipePx, 0f)
                            change.consume()
                        }
                    )
                },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onPlay != null) {
                    IconButton(
                        onClick = { onPlay() },
                        modifier = Modifier
                            .padding(start = 10.dp, top = 12.dp, end = 10.dp, bottom = 10.dp)
                            .size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayCircleFilled,
                            contentDescription = "공부 타이머",
                            tint = Color.Black,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                    Text(
                        text = item.title,
                        fontSize = 20.sp,
                        color = textColor
                    )
                }
                else {
                    Text(
                        text = item.title,
                        fontSize = 20.sp,
                        color = textColor,
                        modifier = Modifier.padding(start = 11.dp, top = 10.dp, bottom = 10.dp)
                    )
                }
            }

            Text(
                text = formatTime(item.seconds),
                fontSize = 20.sp,
                fontFamily = Noto,
                color = textColor,
                modifier = Modifier.padding(end = 11.dp)
            )

        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                //title = { Text("과목 삭제", fontSize = 23.sp, fontWeight = Bold) },
                text = { Text("${item.title}을(를) 삭제하시겠습니까?", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showDialog = false
                            onDelete()
                            offsetXPx = 0f
                        }
                    ) {
                        Text("삭제", fontSize = 16.sp, color = Color.Black, fontWeight = FontWeight.SemiBold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDialog = false }) {
                        Text("취소", fontSize = 16.sp, color = Color.Black, fontWeight = FontWeight.SemiBold)
                    }
                },
                containerColor = Color.White,
                titleContentColor = Color.Black,
                textContentColor = Color.Black,
                shape = RoundedCornerShape(10.dp),
                tonalElevation = 0.dp
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun StudyTimerItemDialogPreview() {
    val sampleItem = StudyItem(
        title = "알고리즘",
        seconds = 3600
    )

    StudyTimerItem(
        item = sampleItem,
        onPlay = {},
        onDelete = {},
        initialShowDialog = false,   // ⭐ 프리뷰에서 항상 AlertDialog 띄우기
        textColor = Color.Black
    )
}

@Preview(showBackground = true, name = "StudyTimerItem - Without Play")
@Composable
fun StudyTimerItemWithoutPlayPreview() {
    val sampleItem = StudyItem(
        title = "운영체제",
        seconds = 5400
    )

    StudyTimerItem(
        item = sampleItem,
        onPlay = null,        // ❌ 재생 버튼 감추기
        onDelete = {},
        initialShowDialog = false,
        textColor = Color.Black
    )
}